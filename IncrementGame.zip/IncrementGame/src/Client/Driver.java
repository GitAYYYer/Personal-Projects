package Client;
import GUI.Frame;

public class Driver
{
	public static void main(String args[])
	{
		Frame frame = new Frame();
	}
}
