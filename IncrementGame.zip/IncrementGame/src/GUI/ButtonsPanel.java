package GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

import Listeners.BulldogListener;

@SuppressWarnings("serial")
public class ButtonsPanel extends JPanel
{
	//focus on managing 2 buttons for now.
	private JButton bulldog = new JButton("BULLDOG");
	private JButton pug = new JButton("PUG");
	private int bulldogCounter = 1;
	private int pugCounter = 1;
	private Map<String, Integer> counters = new HashMap<String, Integer>();
	
	public ButtonsPanel(Frame frame)
	{
		setPreferredSize(new Dimension(300, 700));
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		setBackground(Color.GREEN);
		bulldog.addActionListener(new BulldogListener(frame));
		add(bulldog);
		add(pug);
	}
	
	public void addBulldog()
	{
		counters.put("bulldog", bulldogCounter++);	//bulldogCounter++ stays at 0 if equal to 0 the first time.
		System.out.println(counters);				//buying more after will properly increment though.
	}
	
	public void addPug()
	{
		pugCounter++;
	}
	
	public Map<String, Integer> getCounters()
	{
		return counters;
	}
}
