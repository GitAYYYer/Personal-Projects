package GUI;

import java.awt.Color;
import java.awt.Dimension;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

import Listeners.BulldogListener;
import Listeners.PugListener;

@SuppressWarnings("serial")
public class ButtonsPanel extends JPanel
{
	//focus on managing 2 buttons for now.
	private JButton bulldog = new JButton("BULLDOG");
	private JButton pug = new JButton("PUG");
	private int bulldogCounter = 0;
	private int pugCounter = 0;
	private Map<String, Integer> counters = new HashMap<String, Integer>();
	
	public ButtonsPanel(Frame frame)
	{
		setPreferredSize(new Dimension(300, 700));
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		setBackground(Color.GREEN);
		bulldog.addActionListener(new BulldogListener(frame));
		pug.addActionListener(new PugListener(frame));
		add(bulldog);
		add(pug);
	}
	
	public int incrementBulldogCounter()
	{
		bulldogCounter++;
		return bulldogCounter;
	}
	
	public int incrementPugCounter()
	{
		pugCounter++;
		return pugCounter;
	}
	
	public Map<String, Integer> getCounters()
	{
		return counters;
	}
}
