package GUI;

import java.awt.Dimension;

import javax.swing.JButton;

import Listeners.ClickListener;

@SuppressWarnings("serial")
public class ClickMe extends JButton
{
	public ClickMe(Frame frame)
	{
		setPreferredSize(new Dimension(1050, 621));
		setText("Click Me!");
		addActionListener(new ClickListener(frame));
	}
}
