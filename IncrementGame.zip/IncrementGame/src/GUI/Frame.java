package GUI;

import java.awt.BorderLayout;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Frame extends JFrame implements WindowListener
{
	private MainPanel main = new MainPanel(this);
	private ButtonsPanel buttons = new ButtonsPanel(this);
	private boolean running = true;
	public Frame()
	{
		setTitle("Clicker");
		setBounds(0, 10, 1000, 700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addWindowListener(this);

		add(main, BorderLayout.CENTER);
		add(buttons, BorderLayout.EAST);

		setVisible(true);
		whileRunning();
	}

	public MainPanel getMain()
	{
		return main;
	}

	public ButtonsPanel getButtons()
	{
		return buttons;
	}

	@Override
	public void windowActivated(WindowEvent arg0) 
	{

	}

	@Override
	public void windowClosed(WindowEvent arg0)
	{

	}

	@Override
	public void windowClosing(WindowEvent arg0) 
	{
		running = false;
	}

	@Override
	public void windowDeactivated(WindowEvent arg0)
	{

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) 
	{

	}

	@Override
	public void windowIconified(WindowEvent arg0)
	{

	}

	@Override
	public void windowOpened(WindowEvent arg0)
	{

	}

	public void whileRunning()
	{
		new Thread()
		{
			public void run()
			{
				while (running)
				{
					try
					{
						Thread.sleep(1000);
					}
					catch (InterruptedException e)
					{
						Thread.currentThread().interrupt();
					}

					int current = Integer.parseInt(getMain().getTotalBar().getTotal().getText());
					int amount = 0;

					for (String counter : getButtons().getCounters().keySet())
					{
						System.out.println(counter);
						switch (counter)
						{
						case ("bulldog"):
							amount += 1 * getButtons().getCounters().get(counter);
						break;
						
						case("pug"):
							amount += 2 * getButtons().getCounters().get(counter);
						break;
						}
					}

					getMain().getTotalBar().getTotal().setText(current + amount + "");
				}
			}
		}.start();
	}
}
