package GUI;

import java.awt.BorderLayout;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Frame extends JFrame implements WindowListener
{
	private MainPanel main = new MainPanel(this);
	private ButtonsPanel buttons = new ButtonsPanel(this);
	double current = 0;
	private boolean running = true;
	public Frame()
	{
		setTitle("Clicker");
		setBounds(0, 10, 1000, 700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addWindowListener(this);

		add(main, BorderLayout.CENTER);
		add(buttons, BorderLayout.EAST);

		setVisible(true);
		whileRunning();
	}

	public MainPanel getMain()
	{
		return main;
	}

	public ButtonsPanel getButtons()
	{
		return buttons;
	}

	@Override
	public void windowActivated(WindowEvent arg0) 
	{

	}

	@Override
	public void windowClosed(WindowEvent arg0)
	{

	}

	@Override
	public void windowClosing(WindowEvent arg0) 
	{
		running = false;
	}

	@Override
	public void windowDeactivated(WindowEvent arg0)
	{

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) 
	{

	}

	@Override
	public void windowIconified(WindowEvent arg0)
	{

	}

	@Override
	public void windowOpened(WindowEvent arg0)
	{

	}
	
	public void buyBulldog()
	{
		getButtons().getCounters().put("bulldog", getButtons().incrementBulldogCounter());	//bulldogCounter++ stays at 0 if equal to 0 the first time.
					//buying more after will properly increment though.
		current -= 5;
	}
	
	public void buyPug()
	{
		getButtons().getCounters().put("pug", getButtons().incrementPugCounter());
		current -= 10;
	}
	
	public void incrementTotal()
	{
		current++;
		long intPart = (long) current;
		getMain().getTotalBar().getTotal().setText(intPart + 1 + "");
	}

	public void whileRunning()
	{
		new Thread()
		{
			public void run()
			{
				while (running)
				{
					try
					{
						Thread.sleep(10);
					}
					catch (InterruptedException e)
					{
						Thread.currentThread().interrupt();
					}
					//current is constantly taking the value of the label = 0, so it never increases more than 0.1
					for (String counter : getButtons().getCounters().keySet())
					{
						switch (counter)
						{
						case ("bulldog"):
							current += 0.005 * getButtons().getCounters().get(counter);
						break;
						
						case("pug"):
							current += 0.006 * getButtons().getCounters().get(counter);
						break;
						}
					}
					
					long intPart = (long) current;
					getMain().getTotalBar().getTotal().setText(intPart + "");
				}
			}
		}.start();
	}
}
