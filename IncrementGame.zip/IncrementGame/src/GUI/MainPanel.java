package GUI;

import java.awt.BorderLayout;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class MainPanel extends JPanel
{
	private TotalBar totalBar = new TotalBar();
	public MainPanel(Frame frame)
	{
		ClickMe clicker = new ClickMe(frame);
		add(totalBar, BorderLayout.NORTH);
		add(clicker, BorderLayout.CENTER);
	}
	
	public TotalBar getTotalBar()
	{
		return totalBar;
	}
}
