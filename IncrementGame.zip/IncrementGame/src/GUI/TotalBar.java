package GUI;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class TotalBar extends JPanel
{
	private JLabel total = new JLabel("0");
	public TotalBar()
	{
		setBackground(Color.YELLOW);
		total.setPreferredSize(new Dimension(1350, 20));
		total.setHorizontalAlignment(JLabel.CENTER);
		total.revalidate();
		add(total);
	}
	
	public JLabel getTotal()
	{
		return total;
	}
}
