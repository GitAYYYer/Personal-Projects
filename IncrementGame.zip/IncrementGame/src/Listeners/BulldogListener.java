package Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.Frame;

public class BulldogListener implements ActionListener
{
	Frame frame;

	public BulldogListener(Frame frame)
	{
		this.frame = frame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		//first, check if the current amount is at least 5. If it is, you remove 5 and increment bulldogCounter.
		new Thread()
		{
			public void run()
			{
				double current = Double.parseDouble(frame.getMain().getTotalBar().getTotal().getText());
				if (current >= 5)
				{
					frame.buyBulldog();
				}
			}
		}.start();
	}
}
