package Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.Frame;

public class ClickListener implements ActionListener
{
	private Frame frame;
	public ClickListener(Frame frame)
	{
		this.frame = frame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		new Thread()
		{
			public void run()
			{
				frame.incrementTotal();
			}
		}.start();
	}
}
