package Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.Frame;

public class PugListener implements ActionListener
{
	Frame frame;

	public PugListener(Frame frame)
	{
		this.frame = frame;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) 
	{
		new Thread()
		{
			public void run()
			{
				int current = Integer.parseInt(frame.getMain().getTotalBar().getTotal().getText());
				if (current >= 10)
				{
					frame.buyPug();
				}
			}
		}.start();
	}
}
